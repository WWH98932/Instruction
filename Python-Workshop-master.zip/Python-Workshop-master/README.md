# Python-Workshop
Material for Python Workshops for UCLA MAE program.

More material will be added incrementally as time goes on. 

## References: 

NumPy Tutorials: 

* [Documentation](https://docs.scipy.org/doc/numpy-dev/user/quickstart.html)
* [Tutorial 1](https://www.datacamp.com/community/tutorials/python-numpy-tutorial )
* [Tutorial 2](http://cs231n.github.io/python-numpy-tutorial/)


